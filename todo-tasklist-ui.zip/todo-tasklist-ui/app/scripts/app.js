'use strict';

/**
 * @ngdoc overview
 * @name newBalanceApp
 * @description
 * # newBalanceApp
 *
 * Main module of the application.
 */
angular
  .module('newBalanceApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch'
  ])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/home', {
        templateUrl: 'views/tasks-lists.html',
        controller: 'MainCtrl',
        resolve : {
            todoLists : function($http){
                return $http.get('/todo-tasklist/task/find').then(function (response){
                    return response.data;
                },function (error){
                    console.log(error);
                });
            }
        }
      })
      .when('/create', {
        templateUrl: 'views/create-task-list.html',
        controller: 'MainCtrl',
        resolve : {
            
        }
      })
      .otherwise({
        redirectTo: '/home'
      });
  });
