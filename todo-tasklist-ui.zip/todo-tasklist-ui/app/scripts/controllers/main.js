'use strict';

/**
 * @ngdoc function
 * @name newBalanceApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the newBalanceApp
 */
angular.module('newBalanceApp')
  .controller('MainCtrl', function ($scope, $routeParams, $filter,$http,todoLists) {
  
    var todos = $scope.todos = todoLists;

    $scope.newTodo = '';
    $scope.editedTaskId = '';
    $scope.editedTodo = null;

    $scope.$on('$routeChangeSuccess', function () {
        var status = $scope.status = $routeParams.status || '';
        $scope.statusFilter = (status === 'active') ?
            { completed: false } : (status === 'completed') ?
            { completed: true } : {};
    });

    $scope.addTodo = function () {
         if($scope.newTodo){
             var data = {taskName: 'todo',description : $scope.newTodo,status:'active',startDate : new Date(),endDate : new Date('2018-12-31'),lastUpdatedDate : new Date(),lastUpdatedUser : 'testUser'};
             $http.post('/todo-tasklist/task/create',data).then(function success(response){
                 console.log(response);
                 $scope.newTodo = void 0;
                 $http.get('/todo-tasklist/task/find').then(function (response){
                     $scope.todos = response.data;
                     alert('successfully added task');
                 },function (error){
                     console.log(error);
                 });
             },function error(error){
                 console.error(error);
             });
         }else{
             alert('Please enter value in the description');
         }
    };

    $scope.editTodo = function (todo) {
        $scope.editedTaskId = todo.id;
        $scope.editedTodo = angular.copy(todo);
        // Clone the original todo to restore it on demand.
        $scope.originalTodo = angular.extend({}, todo);
    };

    $scope.save = function (todo) {
        if($scope.tasklistForm.$valid){
            var data = {id:$scope.editedTodo.id, taskName: $scope.editedTodo.taskName,description : $scope.editedTodo.description,status:$scope.editedTodo.status,startDate : new Date(),endDate : new Date('2018-12-31'),lastUpdatedDate : new Date(),lastUpdatedUser : 'testUser'};
            $http.post('/todo-tasklist/task/update',data).then(function success(response){
                console.log(response);
                $scope.editedTaskId = null;
                $http.get('/todo-tasklist/task/find').then(function (response){
                    $scope.todos = response.data;
                    alert('successfully updated task');
                },function (error){
                    console.log(error);
                });
            },function error(error){
                console.error(error);
            });
        }else{
            alert('Please make sure to enter value in the task name and description');
        }
   
    };
    
    
    $scope.selectAllCheck = function(){
        
    }
    
    
    
    $scope.cancel = function(){
        $scope.editedTaskId = null;
    }

    $scope.revertEdits = function (todo) {
        todos[todos.indexOf(todo)] = $scope.originalTodo;
        $scope.editedTodo = null;
        $scope.originalTodo = null;
        $scope.reverted = true;
    };

    $scope.removeTodo = function (id) {
        var data = {};
        $http.post('/todo-tasklist/task/'+ id + '/delete', data).then(function success(response){
            console.log(response);
            $http.get('/todo-tasklist/task/find').then(function (response){
                $scope.todos = response.data;
                alert('successfully deleted task');
            },function (error){
                console.log(error);
            });
        },function error(error){
            console.error(error);
        });
    };

    $scope.saveTodo = function (todo) {
    };

    $scope.toggleCompleted = function (todo, completed) {
        if (angular.isDefined(completed)) {
            todo.completed = completed;
        }
        
    };

    $scope.clearCompletedTodos = function () {
    };

    $scope.markAll = function (completed) {
        todos.forEach(function (todo) {
            if (todo.completed !== completed) {
                $scope.toggleCompleted(todo, completed);
            }
        });
    };

  });
