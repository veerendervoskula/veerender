# todo-list-ui

This project is generated with [yo angular generator](https://github.com/yeoman/generator-angular)
version 0.15.1.

1)Before running this project make sure you have following installed in your machine:
---------------------------------------------------------------------------------
 "node": ">=0.10.0"
 "npm" : ">5.4.2"
 bower,
 grunt,
 karma

2)Once these are all installed in your machine...run 'npm install'
then run 'bower install'

3)## Build & development
----------------------
Run `grunt` for building and `grunt serve` for preview.

Note:- If you face any issues in running the app using 'grunt serve', then forcefully run the app using 'grunt serve --f'
-----

4)## Testing
-------------
Running `grunt test` will run the unit tests with karma.
