Spring Mvc with JDBC -Todolist
==================

The Datasource configuration cab be easily found in
src/main/resources ->  spring-datasource.xml

and its property placholder can be found in 
src/main/resources ->  datasource.properties

Just replace the values that will suit your configuration.

To run the application. just simply type
-------------------------------------------
mvn clean install
mvn jetty:run

now jetty will be running on port 7256. 