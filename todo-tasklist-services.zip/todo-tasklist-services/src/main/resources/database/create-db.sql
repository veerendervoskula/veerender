----------------------------------START....Each time it will drop table to create fresh table-------------------------------------------------------
drop table if exists task_list;
drop sequence if exists task_list_Q1;

------------------------------------------------------------------------

CREATE TABLE task_list (
  task_id INTEGER(11) NOT NULL PRIMARY KEY,
  task_name varchar(45) NOT NULL,
  description varchar(99) NOT NULL,
  status varchar(45) NOT NULL,
  start_date date(45) NOT NULL,
  end_date date(45) NOT NULL,
  last_updated_date date(45) NOT NULL,
  last_updated_user varchar(45) NOT NULL
);

create sequence task_list_Q1 increment by 1 start with 100 maxvalue 999999999;
