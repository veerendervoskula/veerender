INSERT INTO task_list  VALUES (1,'Eat', 'make sure eat in small intervals rather than heavily at a time','completed',CURRENT_TIMESTAMP,'2018-12-31',CURRENT_TIMESTAMP,'vue');

INSERT INTO task_list  VALUES (2,'sleep', 'make sure sleep tightly for 8 hrs a day','active',CURRENT_TIMESTAMP,'2018-12-31',CURRENT_TIMESTAMP,'vue');

INSERT INTO task_list  VALUES (3,'work out', 'make sure to get some physical excercises','active',CURRENT_TIMESTAMP,'2018-12-31',CURRENT_TIMESTAMP,'vue');

