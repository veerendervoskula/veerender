package com.pkma.standalone;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.pkma.spring.common.BeanContextConfig;
import com.pkma.spring.common.DataSourceConfig;

@Configuration
@EnableTransactionManagement
@Import({BeanContextConfig.class, DataSourceConfig.class})
public class StandaloneWebMvcConfig extends WebMvcConfigurerAdapter {

}
