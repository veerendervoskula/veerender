package com.pkma.spring.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.pkma.spring.model.TaskModel;

public class TasksResultSetExtractor implements ResultSetExtractor<TaskModel> {

	@Autowired
	private TasksRowMapper taskRowMapper;

	@Override
	public TaskModel extractData(final ResultSet resultSet)
			throws SQLException, DataAccessException {
		int rowNum = 0;
		TaskModel taskModel = new TaskModel();
		while (resultSet.next()) {
			taskModel = taskRowMapper.mapRow(resultSet, rowNum++);
		}
		return taskModel;
	}
}
