package com.pkma.spring.dao;

import java.util.List;

import com.pkma.spring.model.TaskModel;

public interface TasksDao {
	List<TaskModel> findAllTasks();
	TaskModel viewTask(Integer TaskModelId);
	TaskModel createTask(TaskModel taskModel);
	TaskModel updateTask(TaskModel taskModel);
	TaskModel deleteTask(Integer taskId);
}
