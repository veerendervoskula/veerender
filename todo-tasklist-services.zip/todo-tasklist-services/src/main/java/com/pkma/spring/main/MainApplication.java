/**
 * 
 */
package com.pkma.spring.main;

import java.sql.SQLException;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.pkma.spring.services.TasksService;
import com.pkma.standalone.StandaloneAppConfig;

public class MainApplication {
	public static void main(final String[] args) throws SQLException {

		final AbstractApplicationContext context = new AnnotationConfigApplicationContext(
				StandaloneAppConfig.class);

		TasksService tasksService = (TasksService) context
				.getBean("tasksService");
		System.out.println(tasksService.findAllTasks());

		context.registerShutdownHook();
		context.close();
	}
}
