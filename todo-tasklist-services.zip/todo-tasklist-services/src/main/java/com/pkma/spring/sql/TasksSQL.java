/**
 * 
 */
package com.pkma.spring.sql;

public class TasksSQL {

    public static final String GET_ALL_TASKS = getAllTasksSelectSql();
    public static final String GET_TASK = getTaskSelectSql();
    public static final String CREATE_TASK = taskInsertSql();
    public static final String UPDATE_TASK = taskUpdateSql();
    public static final String DELETE_TASK = taskDeleteSql();

    private static String getAllTasksSelectSql() {
        final StringBuilder sql = new StringBuilder();
        sql.append("select * from task_list");
        return sql.toString();
    }

    private static String taskDeleteSql() {
        final StringBuilder sql = new StringBuilder();
        sql.append("delete from task_list\n");
        sql.append("where task_id = :task_id");
        return sql.toString();
    }

    private static String taskUpdateSql() {
        final StringBuilder sql = new StringBuilder();
        sql.append("update task_list set \n");
        sql.append("task_id = :task_id,\n");
        sql.append("task_name = :task_name,\n");
        sql.append("description = :description,\n");
        sql.append("status = :status,\n");
        sql.append("start_date = :start_date,\n");
        sql.append("end_date = :end_date,\n");
        sql.append("last_updated_date = :last_updated_date,\n");
        sql.append("last_updated_user = :last_updated_user\n");
        sql.append("where task_id = :task_id");
        return sql.toString();
    }

    private static String taskInsertSql() {
        final StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO task_list (\n");
        sql.append("task_id,\n");
        sql.append("task_name,\n");
        sql.append("description,\n");
        sql.append("status,\n");
        sql.append("start_date,\n");
        sql.append("end_date,\n");
        sql.append("last_updated_date,\n");
        sql.append("last_updated_user)\n");
        sql.append("VALUES (task_list_Q1.nextval, :task_name, :description, :status, :start_date, :end_date, :last_updated_date, :last_updated_user)");
        return sql.toString();
    }
    private static String getTaskSelectSql() {
        final StringBuilder sql = new StringBuilder();
        sql.append("select * from task_list\n");
        sql.append("where task_id = :task_id");
        return sql.toString();
    }
}
