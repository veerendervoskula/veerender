package com.pkma.spring.common;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.pkma.spring.controller.TaskController;
import com.pkma.spring.dao.SequenceDao;
import com.pkma.spring.dao.SequenceDaoImpl;
import com.pkma.spring.dao.TasksDao;
import com.pkma.spring.dao.TasksDaoImpl;
import com.pkma.spring.dao.TasksResultSetExtractor;
import com.pkma.spring.dao.TasksRowMapper;
import com.pkma.spring.services.TasksService;
import com.pkma.spring.services.TasksServiceImpl;

// If there are plenty of beans then isolate them into seperate classes
@Configuration
public class BeanContextConfig {

    @Bean
    public TaskController playerController() {
        return new TaskController();
    }

    @Bean
    public TasksService tasksService() {
        return new TasksServiceImpl();
    }

    @Bean
    public TasksDao tasksDao() {
        return new TasksDaoImpl();
    }

    @Bean
    public TasksRowMapper taskRowMapper() {
        return new TasksRowMapper();
    }

    @Bean
    public TasksResultSetExtractor taskResultSetExtractor() {
        return new TasksResultSetExtractor();
    }

    @Bean
    public SequenceDao sequenceDao() {
        return new SequenceDaoImpl();
    }
}
