package com.pkma.spring.services;

import java.util.List;

import com.pkma.spring.model.TaskModel;

public interface TasksService {
	List<TaskModel> findAllTasks();
	TaskModel viewTask(Integer playerId);
	TaskModel createTask(TaskModel taskModel);
	TaskModel updateTask(TaskModel taskModel);
	TaskModel deleteTask(Integer taskId);
}
