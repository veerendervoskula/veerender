package com.pkma.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pkma.spring.model.TaskModel;
import com.pkma.spring.services.TasksService;
@Controller
@RequestMapping(value = "/task/")
public class TaskController {

    @Autowired
    private TasksService tasksService;

    @ResponseBody
    @RequestMapping(value = "find", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json")
    public List<TaskModel> findAllTasks() {
        return tasksService.findAllTasks();
    }

    @ResponseBody
    @RequestMapping(value = "{taskId}/view", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public TaskModel viewTask(@PathVariable final Integer taskId) {
        return tasksService.viewTask(taskId);
    }

    @ResponseBody
    @RequestMapping(value = "create", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public TaskModel createTask(@RequestBody final TaskModel taskModel) {
        return tasksService.createTask(taskModel);
    }

    @ResponseBody
    @RequestMapping(value = "update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public TaskModel updateTask(@RequestBody final TaskModel taskModel) {
        return tasksService.updateTask(taskModel);
    }

    @ResponseBody
    @RequestMapping(value = "{taskId}/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public TaskModel deleteTask(@PathVariable final Integer taskId) {
        return tasksService.deleteTask(taskId);
    }
}
