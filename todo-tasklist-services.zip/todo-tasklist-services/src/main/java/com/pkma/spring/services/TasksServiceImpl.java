package com.pkma.spring.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pkma.spring.dao.TasksDao;
import com.pkma.spring.model.TaskModel;

@Service
public class TasksServiceImpl implements TasksService {

    @Autowired
    private TasksDao tasksDao;

    @Override
    public List<TaskModel> findAllTasks() {
        return tasksDao.findAllTasks();
    }

    @Override
    public TaskModel viewTask(final Integer TaskModelId) {
        return tasksDao.viewTask(TaskModelId);
    }

    @Override
    @Transactional
    public TaskModel createTask(final TaskModel taskModel) {
        return tasksDao.createTask(taskModel);
    }

    @Override
    @Transactional
    public TaskModel updateTask(final TaskModel taskModel) {
        return tasksDao.updateTask(taskModel);
    }

    @Override
    @Transactional
    public TaskModel deleteTask(final Integer taskId) {
        return tasksDao.deleteTask(taskId);
    }

}
