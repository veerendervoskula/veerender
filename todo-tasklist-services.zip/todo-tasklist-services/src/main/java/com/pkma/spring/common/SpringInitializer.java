/*
 * Uncomment this when you dont to use web.xml
 */

//package com.pkma.spring.common;
//
//import javax.servlet.ServletContext;
//import javax.servlet.ServletException;
//import javax.servlet.ServletRegistration;
//
//import org.springframework.web.WebApplicationInitializer;
//import org.springframework.web.context.ContextLoaderListener;
//import org.springframework.web.context.WebApplicationContext;
//import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
//import org.springframework.web.servlet.DispatcherServlet;
//
//public class SpringInitializer implements WebApplicationInitializer {
//
//    private static final String CONFIG_LOCATION = "com.pkma.spring.config";
//    private static final String MAPPING_URL = "/*";
//
//    @Override
//    public void onStartup(final ServletContext servletContext) throws ServletException {
//        final WebApplicationContext context = getContext();
//        servletContext.addListener(new ContextLoaderListener(context));
//        final ServletRegistration.Dynamic dispatcher = servletContext.addServlet("DispatcherServlet",
//                new DispatcherServlet(context));
//        dispatcher.setLoadOnStartup(1);
//        dispatcher.addMapping(MAPPING_URL);
//    }
//
//    private AnnotationConfigWebApplicationContext getContext() {
//        final AnnotationConfigWebApplicationContext context = new AnnotationConfigWebApplicationContext();
//        context.setConfigLocation(CONFIG_LOCATION);
//        return context;
//    }
//
// }