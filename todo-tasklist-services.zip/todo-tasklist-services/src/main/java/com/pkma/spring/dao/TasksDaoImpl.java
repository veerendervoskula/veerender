package com.pkma.spring.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.pkma.spring.model.TaskModel;
import com.pkma.spring.sql.TasksSQL;

@Repository
public class TasksDaoImpl implements TasksDao {

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    @Autowired
    private TasksResultSetExtractor taskResultSetExtractor;
    @Autowired
    private TasksRowMapper taskRowMapper;
    @Autowired
    private SequenceDao sequenceDao;

    @Override
    public List<TaskModel> findAllTasks() {
        final String sql = TasksSQL.GET_ALL_TASKS;
        final List<TaskModel> tasks = namedParameterJdbcTemplate.query(sql, taskRowMapper);
        return tasks;
    }

    @Override
    public TaskModel viewTask(final Integer taskId) {
        final String sql = TasksSQL.GET_TASK;
        final MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("task_id", taskId);
        return namedParameterJdbcTemplate.query(sql, params, taskResultSetExtractor);
    }

    @Override
    public TaskModel createTask(final TaskModel taskModel) {
        final String sql = TasksSQL.CREATE_TASK;
        final MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("task_name", taskModel.getTaskName());
        params.addValue("description", taskModel.getDescription());
        params.addValue("status", taskModel.getStatus());
        params.addValue("start_date", taskModel.getStartDate());
        params.addValue("end_date", taskModel.getEndDate());
        params.addValue("last_updated_date", taskModel.getLastUpdatedDate());
        params.addValue("last_updated_user", taskModel.getLastUpdatedUser());
        final int i = namedParameterJdbcTemplate.update(sql, params);
        if (i == 0) {
            // failed to insert..log the message
        }
        return null;
    }

    @Override
    public TaskModel updateTask(final TaskModel taskModel) {
        final String sql = TasksSQL.UPDATE_TASK;
        final MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("task_id", taskModel.getId());
        params.addValue("task_name", taskModel.getTaskName());
        params.addValue("description", taskModel.getDescription());
        params.addValue("status", taskModel.getStatus());
        params.addValue("start_date", taskModel.getStartDate());
        params.addValue("end_date", taskModel.getEndDate());
        params.addValue("last_updated_date", taskModel.getLastUpdatedDate());
        params.addValue("last_updated_user", taskModel.getLastUpdatedUser());

        final int i = namedParameterJdbcTemplate.update(sql, params);
        if (i == 0) {
            // failed to insert..log the message
        }
        return null;
    }

    @Override
    public TaskModel deleteTask(final Integer taskId) {
        final String sql = TasksSQL.DELETE_TASK;
        final MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("task_id", taskId);
        final int i = namedParameterJdbcTemplate.update(sql, params);
        if (i == 0) {
            // failed to delete
        }
        return null;
    }

}
