package com.pkma.spring.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.pkma.spring.model.TaskModel;

public class TasksRowMapper implements RowMapper<TaskModel> {

    @Override
    public TaskModel mapRow(final ResultSet resultSet, final int rowNum) throws SQLException {
        final TaskModel taskModel = new TaskModel();
        taskModel.setId(resultSet.getInt("task_id"));
        taskModel.setDescription(resultSet.getString("description"));
        taskModel.setStatus(resultSet.getString("status"));
        taskModel.setEndDate(resultSet.getDate("end_date"));
        taskModel.setStartDate(resultSet.getDate("start_date"));
        taskModel.setTaskName(resultSet.getString("task_name"));
        taskModel.setLastUpdatedDate(resultSet.getDate("last_updated_date"));
        taskModel.setLastUpdatedUser(resultSet.getString("last_updated_user"));
        return taskModel;
    }
}
