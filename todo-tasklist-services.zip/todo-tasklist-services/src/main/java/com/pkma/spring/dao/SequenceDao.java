package com.pkma.spring.dao;

public interface SequenceDao {

    Integer getPlayerId(String sequenceName);
}
