package com.pkma.webapp;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({WebappMvcConfig.class})
public class WebappMainConfig {

}
