package com.pkma.webapp;

import java.io.IOException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

import com.pkma.spring.common.BeanContextConfig;
import com.pkma.spring.common.DataSourceConfig;

@PropertySource({"classpath:datasource.properties"})
@Configuration
@EnableTransactionManagement
@Import({BeanContextConfig.class, DataSourceConfig.class})
public class WebappMvcConfig extends WebMvcConfigurationSupport {

    @Bean
    public static PropertySourcesPlaceholderConfigurer appPropertySourcesPlaceholderConfigurer() throws IOException {
        final PropertySourcesPlaceholderConfigurer configurer = new PropertySourcesPlaceholderConfigurer();
        configurer.setIgnoreUnresolvablePlaceholders(true);
        return configurer;
    }
}
